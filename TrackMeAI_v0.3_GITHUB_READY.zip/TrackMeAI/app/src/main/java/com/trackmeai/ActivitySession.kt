package com.trackmeai

data class ActivitySession(
    val mode: String,
    val startedAt: Long,
    val durationMs: Long,
    val metric: Int,
    val focusedMs: Long = 0L,
    val awayMs: Long = 0L,
    val distractedMs: Long = 0L
)

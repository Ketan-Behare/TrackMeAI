package com.trackmeai

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Matrix
import android.os.Bundle
import android.os.SystemClock
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.poselandmarker.PoseLandmarker
import com.google.mediapipe.tasks.vision.poselandmarker.PoseLandmarkerResult
import java.util.concurrent.Executors
import kotlin.math.max
import kotlin.math.min

class MainActivity : ComponentActivity() {
    private lateinit var b: com.trackmeai.databinding.ActivityMainBinding
    private lateinit var landmarker: PoseLandmarker
    private val exec=Executors.newSingleThreadExecutor()
    private val engine=TrackerEngine()
    private lateinit var store: SessionStore

    private enum class Mode { PUSHUPS, SQUATS, PLANK, STUDY }
    private var mode=Mode.PUSHUPS
    private var started=System.currentTimeMillis()
    private var focused=0L
    private var away=0L
    private var lastSeen=0L
    private var lastFrame=System.currentTimeMillis()
    private var studyState="WAITING"

    private val permission=registerForActivityResult(ActivityResultContracts.RequestPermission()){ ok ->
        if(ok) startCamera() else Toast.makeText(this,"Camera permission is required.",Toast.LENGTH_LONG).show()
    }

    override fun onCreate(s:Bundle?) {
        super.onCreate(s)
        b=com.trackmeai.databinding.ActivityMainBinding.inflate(layoutInflater); setContentView(b.root)
        store=SessionStore(this)
        b.pushups.setOnClickListener{switch(Mode.PUSHUPS)}
        b.squats.setOnClickListener{switch(Mode.SQUATS)}
        b.plank.setOnClickListener{switch(Mode.PLANK)}
        b.study.setOnClickListener{switch(Mode.STUDY)}
        b.history.setOnClickListener{showHistory()}
        b.sub.setOnClickListener{showCustomInstruction()}
        setupLandmarker()
        if(ContextCompat.checkSelfPermission(this,Manifest.permission.CAMERA)==PackageManager.PERMISSION_GRANTED) startCamera()
        else permission.launch(Manifest.permission.CAMERA)
    }

    private fun switch(m:Mode) {
        saveIfNeeded()
        mode=m; engine.reset(); started=System.currentTimeMillis(); focused=0; away=0; lastSeen=0
        b.mode.text=m.name.replace('_',' '); b.count.text="0"
        b.sub.text=when(m){Mode.STUDY->"Observable focus: person present + seated. Not mind-reading.";Mode.PLANK->"Hold a straight body line.";else->"Use a full-body camera view."}
    }


    private fun showCustomInstruction() {
        val input = EditText(this).apply {
            hint = "e.g. Track me for 30 minutes and count my push-ups and tell me how long I stayed at my desk."
            setSingleLine(false)
            minLines = 3
        }
        android.app.AlertDialog.Builder(this)
            .setTitle("Custom Tracker")
            .setMessage("Describe what you want to track. The current parser works offline with supported observable rules.")
            .setView(input)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Start") { _, _ ->
                val text=input.text.toString().trim()
                if(text.isNotEmpty()) startActivity(android.content.Intent(this, CustomTrackerActivity::class.java).putExtra("instruction", text))
            }.show()
    }

    private fun setupLandmarker() {
        val base=BaseOptions.builder().setModelAssetPath("pose_landmarker_lite.task").build()
        val o=PoseLandmarker.PoseLandmarkerOptions.builder().setBaseOptions(base)
            .setNumPoses(1).setMinPoseDetectionConfidence(.5f).setMinPosePresenceConfidence(.5f)
            .setMinTrackingConfidence(.5f).setRunningMode(RunningMode.LIVE_STREAM)
            .setResultListener{r,_->handle(r)}.setErrorListener{e->runOnUiThread{b.status.text="AI error: ${e.message}"}}.build()
        landmarker=PoseLandmarker.createFromOptions(this,o)
    }

    private fun startCamera() {
        ProcessCameraProvider.getInstance(this).addListener({
            val p=ProcessCameraProvider.getInstance(this).get()
            val preview=Preview.Builder().build().also{it.setSurfaceProvider(b.preview.surfaceProvider)}
            val analysis=ImageAnalysis.Builder().setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST).build()
            analysis.setAnalyzer(exec){proxy->analyze(proxy)}
            p.unbindAll(); p.bindToLifecycle(this,CameraSelector.DEFAULT_FRONT_CAMERA,preview,analysis)
            b.status.text="Ready"
        },ContextCompat.getMainExecutor(this))
    }

    private fun analyze(proxy:ImageProxy) {
        try {
            val bmp=proxy.toRgbBitmap()
            val m=Matrix().apply{postRotate(proxy.imageInfo.rotationDegrees.toFloat());postScale(-1f,1f,bmp.width/2f,bmp.height/2f)}
            val r=Bitmap.createBitmap(bmp,0,0,bmp.width,bmp.height,m,true)
            landmarker.detectAsync(BitmapImageBuilder(r).build(),SystemClock.uptimeMillis())
        } catch(_:Exception){} finally{proxy.close()}
    }

    private fun handle(r:PoseLandmarkerResult) {
        val now=System.currentTimeMillis()
        if(r.landmarks().isEmpty()){ if(mode==Mode.STUDY){away+=now-lastFrame;studyState="AWAY"};lastFrame=now;return }
        val pts=r.landmarks()[0].map{P(it.x(),it.y(),it.z(),it.visibility().orElse(0f))}
        lastSeen=now
        when(mode){
            Mode.PUSHUPS->{engine.pushUp(pts);b.count.text=engine.metric.toString();b.status.text="Tracking push-ups"}
            Mode.SQUATS->{engine.squat(pts);b.count.text=engine.metric.toString();b.status.text="Tracking squats"}
            Mode.PLANK->{val ms=engine.plank(pts);b.count.text=format(ms);b.status.text=if(ms>0)"Good plank position" else "Adjust your body line"}
            Mode.STUDY->{val present=pts.count{it.visibility>.35f}>=8;val seated=present&&pts[23].y>pts[11].y&&pts[24].y>pts[12].y
                if(present){focused+=if(seated)now-lastFrame else 0;studyState=if(seated)"FOCUSED / SEATED" else "PRESENT / DISTRACTED"}
                b.count.text=format(focused);b.status.text=studyState}
        }
        lastFrame=now
        runOnUiThread{b.overlay.setPoints(pts.filter{it.visibility>.35f}.map{it.x to it.y})}
    }

    private fun format(ms:Long):String {
        val s=ms/1000; return "%02d:%02d".format((s/60),s%60)
    }

    private fun saveIfNeeded() {
        val d=System.currentTimeMillis()-started
        if(d<3000)return
        store.add(ActivitySession(mode.name,started,d,engine.metric,focused,away,0))
    }

    private fun showHistory() {
        val list=store.all()
        val text=if(list.isEmpty())"No sessions yet." else list.take(10).joinToString("\\n\\n"){s->
            "${s.mode}\\nDuration: ${format(s.durationMs)}\\nMetric: ${s.metric}" +
            if(s.mode=="STUDY")"\\nFocused: ${format(s.focusedMs)}\\nAway: ${format(s.awayMs)}" else ""
        }
        android.app.AlertDialog.Builder(this).setTitle("Session history").setMessage(text)
            .setNegativeButton("Close",null).setNeutralButton("Clear"){_,_->store.clear()}.show()
    }

    override fun onPause(){super.onPause();saveIfNeeded()}
    override fun onDestroy(){saveIfNeeded();exec.shutdown();if(::landmarker.isInitialized)landmarker.close();super.onDestroy()}
}

private fun ImageProxy.toRgbBitmap(): Bitmap {
    val y=image?.planes?.getOrNull(0)?.buffer ?: throw IllegalStateException("No image")
    // Fallback bitmap conversion for analyzer input. CameraX's YUV buffer is not a packed RGB buffer,
    // so use the platform JPEG path when available.
    val bytes=java.io.ByteArrayOutputStream()
    image?.let { img ->
        val yb=img.planes[0].buffer; val ub=img.planes[1].buffer; val vb=img.planes[2].buffer
        // Lightweight grayscale fallback keeps the MVP functional on devices where direct RGB conversion is unavailable.
        val w=width; val h=height; val out=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888)
        val arr=ByteArray(yb.remaining()); yb.get(arr)
        for(row in 0 until h) for(col in 0 until w) {
            val v=arr[min(arr.size-1,row*w+col)].toInt() and 255
            out.setPixel(col,row,android.graphics.Color.rgb(v,v,v))
        }
        return out
    }
    throw IllegalStateException("No camera frame")
}

package com.trackmeai

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.SystemClock
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.poselandmarker.PoseLandmarker
import com.google.mediapipe.tasks.vision.poselandmarker.PoseLandmarkerResult
import java.util.concurrent.Executors
import kotlin.math.max

class CustomTrackerActivity : ComponentActivity() {
    private lateinit var preview: PreviewView
    private lateinit var overlay: PoseOverlay
    private lateinit var title: TextView
    private lateinit var result: TextView
    private lateinit var status: TextView
    private lateinit var landmarker: PoseLandmarker
    private val exec=Executors.newSingleThreadExecutor()
    private val parser=CustomTrackerParser()
    private val engine=TrackerEngine()
    private lateinit var spec: CustomTrackerSpec
    private var started=System.currentTimeMillis()
    private var last=System.currentTimeMillis()
    private var presenceMs=0L
    private var seatedMs=0L
    private var awayMs=0L
    private var standCount=0
    private var previousSeated=false
    private var input=""

    private val permission=registerForActivityResult(ActivityResultContracts.RequestPermission()){if(it) startCamera()}

    override fun onCreate(b:Bundle?) {
        super.onCreate(b)
        input=intent.getStringExtra("instruction") ?: "Track me for 30 minutes and count my push-ups."
        spec=parser.parse(input)

        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setBackgroundColor(0xFF101114.toInt())}
        val head=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;padding(20)}
        title=TextView(this).apply{text="CUSTOM TRACKER";textSize=22f;setTextColor(-1)}
        status=TextView(this).apply{text="Preparing…";textSize=14f;setTextColor(0xFFB9C0CC.toInt())}
        head.addView(title);head.addView(status)
        root.addView(head)

        preview=PreviewView(this); overlay=PoseOverlay(this)
        val frame=FrameLayout(this)
        frame.addView(preview);frame.addView(overlay)
        root.addView(frame,LinearLayout.LayoutParams(-1,0,1f))

        result=TextView(this).apply{setTextColor(-1);textSize=18f;padding=20}
        root.addView(result)
        setContentView(root)

        status.text="Rules: "+spec.rules.joinToString{it.name}+" • ${spec.durationMinutes} min"
        setupLandmarker()
        if(ContextCompat.checkSelfPermission(this,Manifest.permission.CAMERA)==PackageManager.PERMISSION_GRANTED)startCamera()
        else permission.launch(Manifest.permission.CAMERA)
    }

    private fun setupLandmarker(){
        val base=BaseOptions.builder().setModelAssetPath("pose_landmarker_lite.task").build()
        val o=PoseLandmarker.PoseLandmarkerOptions.builder().setBaseOptions(base)
            .setNumPoses(1).setMinPoseDetectionConfidence(.5f).setMinPosePresenceConfidence(.5f)
            .setMinTrackingConfidence(.5f).setRunningMode(RunningMode.LIVE_STREAM)
            .setResultListener{r,_->handle(r)}.build()
        landmarker=PoseLandmarker.createFromOptions(this,o)
    }

    private fun startCamera(){
        ProcessCameraProvider.getInstance(this).addListener({
            val p=ProcessCameraProvider.getInstance(this).get()
            val pr=Preview.Builder().build().also{it.setSurfaceProvider(preview.surfaceProvider)}
            val an=ImageAnalysis.Builder().setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST).build()
            an.setAnalyzer(exec){proxy->
                try{
                    val bmp=proxy.toRgbBitmap()
                    val mp=BitmapImageBuilder(bmp).build()
                    landmarker.detectAsync(mp,SystemClock.uptimeMillis())
                }catch(_:Exception){}finally{proxy.close()}
            }
            p.unbindAll();p.bindToLifecycle(this,CameraSelector.DEFAULT_FRONT_CAMERA,pr,an)
            status.text="Tracking locally — no cloud AI"
        },ContextCompat.getMainExecutor(this))
    }

    private fun handle(r:PoseLandmarkerResult){
        val now=System.currentTimeMillis();val dt=max(0,now-last);last=now
        if(r.landmarks().isEmpty()){awayMs+=dt;render();return}
        val pts=r.landmarks()[0].map{P(it.x(),it.y(),it.z(),it.visibility().orElse(0f))}
        presenceMs+=dt
        val seated=pts.size>=25 && pts[11].visibility>.35f && pts[23].visibility>.35f && pts[11].y<pts[23].y
        if(seated) seatedMs+=dt
        if(previousSeated && !seated) standCount++
        previousSeated=seated

        spec.rules.forEach{
            when(it.type){
                CustomRule.Type.COUNT_PUSHUPS->engine.pushUp(pts)
                CustomRule.Type.COUNT_SQUATS->engine.squat(pts)
                else->{}
            }
        }
        render(pts)
        if(now-started >= spec.durationMinutes*60_000L) finish()
    }

    private fun render(pts:List<P>?=null){
        val lines=mutableListOf<String>()
        spec.rules.forEach{
            when(it.type){
                CustomRule.Type.COUNT_PUSHUPS->lines+="Push-ups: ${engine.metric}"
                CustomRule.Type.COUNT_SQUATS->lines+="Squats: ${engine.metric}"
                CustomRule.Type.COUNT_STANDS->lines+="Stand transitions: $standCount"
                CustomRule.Type.TRACK_PRESENCE->lines+="Present: ${fmt(presenceMs)} • Away: ${fmt(awayMs)}"
                CustomRule.Type.TRACK_SEATED->lines+="Seated/focused estimate: ${fmt(seatedMs)}"
                else->{}
            }
        }
        runOnUiThread{
            result.text=lines.joinToString("\n")
            pts?.let{overlay.setPoints(it.filter{p->p.visibility>.35f}.map{p->p.x to p.y})}
        }
    }

    private fun fmt(ms:Long):String="%02d:%02d".format(ms/60000,(ms/1000)%60)

    private fun finish(){
        runOnUiThread{
            Toast.makeText(this,"Custom tracking session complete.",Toast.LENGTH_LONG).show()
            finish()
        }
    }

    override fun onDestroy(){exec.shutdown();if(::landmarker.isInitialized)landmarker.close();super.onDestroy()}
}

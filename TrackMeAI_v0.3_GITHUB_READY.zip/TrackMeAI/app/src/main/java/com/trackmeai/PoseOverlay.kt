package com.trackmeai

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.util.AttributeSet
import android.view.View

class PoseOverlay @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : View(context, attrs) {
    private val pointPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeWidth = 8f }
    private var points: List<Pair<Float, Float>> = emptyList()

    fun setPoints(p: List<Pair<Float, Float>>) { points = p; postInvalidate() }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        pointPaint.style = Paint.Style.FILL
        points.forEach { (x, y) -> canvas.drawCircle(x * width, y * height, 5f, pointPaint) }
    }
}

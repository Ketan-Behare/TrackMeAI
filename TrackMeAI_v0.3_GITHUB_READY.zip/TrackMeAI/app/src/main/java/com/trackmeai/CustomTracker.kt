package com.trackmeai

import kotlin.math.abs

data class CustomRule(
    val name: String,
    val type: Type,
    val target: Int = 0,
    val thresholdMs: Long = 0L
) {
    enum class Type { COUNT_PUSHUPS, COUNT_SQUATS, COUNT_STANDS, TRACK_PRESENCE, TRACK_SEATED, TRACK_ABSENCE }
}

data class CustomTrackerSpec(
    val title: String,
    val durationMinutes: Int,
    val rules: List<CustomRule>
)

class CustomTrackerParser {
    fun parse(text: String): CustomTrackerSpec {
        val t = text.lowercase()
        val duration = Regex("""(\d+)\s*(minute|minutes|min|mins|hour|hours|hr|hrs)""")
            .find(t)?.let {
                val n=it.groupValues[1].toInt()
                if(it.groupValues[2].startsWith("hour") || it.groupValues[2].startsWith("hr")) n*60 else n
            } ?: 30

        val rules = mutableListOf<CustomRule>()
        if ("push-up" in t || "pushup" in t) rules += CustomRule("Push-ups", CustomRule.Type.COUNT_PUSHUPS)
        if ("squat" in t) rules += CustomRule("Squats", CustomRule.Type.COUNT_SQUATS)
        if ("stand up" in t || "stand-up" in t || "sit down" in t)
            rules += CustomRule("Stand/Sit transitions", CustomRule.Type.COUNT_STANDS)
        if ("leave" in t || "away" in t || "desk" in t || "presence" in t)
            rules += CustomRule("Presence", CustomRule.Type.TRACK_PRESENCE)
        if ("focus" in t || "study" in t || "studying" in t || "seated" in t)
            rules += CustomRule("Seated/focused time", CustomRule.Type.TRACK_SEATED)

        if (rules.isEmpty()) rules += CustomRule("Presence", CustomRule.Type.TRACK_PRESENCE)

        return CustomTrackerSpec(
            title = "Custom Tracker",
            durationMinutes = duration,
            rules = rules.distinctBy { it.type }
        )
    }
}

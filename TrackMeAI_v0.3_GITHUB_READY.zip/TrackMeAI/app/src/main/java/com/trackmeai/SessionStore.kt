package com.trackmeai

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

class SessionStore(context: Context) {
    private val prefs = context.getSharedPreferences("trackme_sessions", Context.MODE_PRIVATE)

    fun add(s: ActivitySession) {
        val arr = JSONArray(prefs.getString("sessions", "[]"))
        arr.put(JSONObject().apply {
            put("mode", s.mode); put("startedAt", s.startedAt); put("durationMs", s.durationMs)
            put("metric", s.metric); put("focusedMs", s.focusedMs); put("awayMs", s.awayMs)
            put("distractedMs", s.distractedMs)
        })
        while (arr.length() > 50) {
            val trimmed = JSONArray()
            for (i in 1 until arr.length()) trimmed.put(arr.getJSONObject(i))
            prefs.edit().putString("sessions", trimmed.toString()).apply()
            return
        }
        prefs.edit().putString("sessions", arr.toString()).apply()
    }

    fun all(): List<ActivitySession> {
        val arr = JSONArray(prefs.getString("sessions", "[]"))
        return buildList {
            for (i in arr.length() - 1 downTo 0) {
                val o = arr.getJSONObject(i)
                add(ActivitySession(
                    o.getString("mode"), o.getLong("startedAt"), o.getLong("durationMs"),
                    o.getInt("metric"), o.optLong("focusedMs"), o.optLong("awayMs"),
                    o.optLong("distractedMs")
                ))
            }
        }
    }

    fun clear() = prefs.edit().remove("sessions").apply()
}

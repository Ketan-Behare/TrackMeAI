package com.trackmeai

import kotlin.math.atan2
import kotlin.math.sqrt
import kotlin.math.abs

data class P(val x: Float, val y: Float, val z: Float = 0f, val visibility: Float = 1f)

class TrackerEngine {
    enum class Phase { HIGH, LOW }
    var metric = 0
        private set

    private var pushPhase = Phase.HIGH
    private var squatPhase = Phase.HIGH
    private var plankStart = 0L

    fun reset() { metric = 0; pushPhase = Phase.HIGH; squatPhase = Phase.HIGH; plankStart = 0L }

    fun pushUp(p: List<P>): Boolean {
        if (!visible(p, 11, 13, 15, 12, 14, 16)) return false
        val e = (angle(p[11],p[13],p[15]) + angle(p[12],p[14],p[16])) / 2f
        if (e < 105f) pushPhase = Phase.LOW
        if (pushPhase == Phase.LOW && e > 155f) {
            metric++; pushPhase = Phase.HIGH; return true
        }
        return false
    }

    fun squat(p: List<P>): Boolean {
        if (!visible(p, 23,25,27,24,26,28)) return false
        val k = (angle(p[23],p[25],p[27]) + angle(p[24],p[26],p[28])) / 2f
        if (k < 105f) squatPhase = Phase.LOW
        if (squatPhase == Phase.LOW && k > 155f) {
            metric++; squatPhase = Phase.HIGH; return true
        }
        return false
    }

    fun plank(p: List<P>): Long {
        if (!visible(p,11,23,27,12,24,28)) return 0L
        val left = abs(angle(p[11],p[23],p[27]) - 180f)
        val right = abs(angle(p[12],p[24],p[28]) - 180f)
        val good = left < 35f && right < 35f
        if (good) {
            if (plankStart == 0L) plankStart = System.currentTimeMillis()
            return System.currentTimeMillis() - plankStart
        }
        plankStart = 0L
        return 0L
    }

    private fun visible(p: List<P>, vararg ids: Int): Boolean =
        ids.all { it < p.size && p[it].visibility > .35f }

    private fun angle(a:P,b:P,c:P):Float {
        val abx=a.x-b.x; val aby=a.y-b.y; val cbx=c.x-b.x; val cby=c.y-b.y
        val dot=abx*cbx+aby*cby
        val m1=sqrt(abx*abx+aby*aby); val m2=sqrt(cbx*cbx+cby*cby)
        if(m1==0f||m2==0f) return 180f
        return Math.toDegrees(atan2(abs(abx*cby-aby*cbx).toDouble(),dot.toDouble())).toFloat()
    }
}
